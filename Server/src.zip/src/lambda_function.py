"""
PerformanceTraining Score Server
統合Lambda関数 - zipアップロード用

エンドポイント:
- POST /submit       : スコア送信
- GET  /scores       : 全スコア取得
- GET  /scores/{user}: ユーザー別スコア取得
- GET  /ranking/{ex} : 課題別ランキング取得
"""
import json
import os
import boto3
from datetime import datetime
from decimal import Decimal

# DynamoDB設定
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get('TABLE_NAME', 'PerformanceTrainingScores')
table = dynamodb.Table(TABLE_NAME)


class DecimalEncoder(json.JSONEncoder):
    """Decimal型をJSONシリアライズするためのエンコーダー"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)


def create_response(status_code, body):
    """共通レスポンス生成"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, cls=DecimalEncoder, ensure_ascii=False)
    }


def lambda_handler(event, context):
    """
    メインハンドラー
    API Gateway からのリクエストをルーティング
    """
    try:
        http_method = event.get('httpMethod', '')
        path = event.get('path', '')
        path_params = event.get('pathParameters') or {}

        # OPTIONSリクエスト（CORS preflight）
        if http_method == 'OPTIONS':
            return create_response(200, {})

        # ルーティング
        if http_method == 'POST' and path == '/submit':
            return handle_submit(event)

        elif http_method == 'GET' and path == '/scores':
            return handle_get_all_scores()

        elif http_method == 'GET' and path.startswith('/scores/'):
            user_name = path_params.get('userName') or path.split('/scores/')[-1]
            return handle_get_user_scores(user_name)

        elif http_method == 'GET' and path.startswith('/ranking/'):
            exercise_id = path_params.get('exerciseId') or path.split('/ranking/')[-1]
            return handle_get_ranking(exercise_id)

        else:
            return create_response(404, {'error': 'Not Found'})

    except Exception as e:
        print(f'Error: {str(e)}')
        return create_response(500, {'error': 'Internal server error'})


def handle_submit(event):
    """
    スコア送信処理

    Request Body:
    {
        "userName": "string",
        "exerciseId": "Memory" | "CPU" | "Tradeoff",
        "score": number,
        "details": { ... }
    }
    """
    try:
        body = json.loads(event.get('body', '{}'))

        user_name = body.get('userName', '').strip()
        exercise_id = body.get('exerciseId', '').strip()
        score = body.get('score', 0)
        details = body.get('details', {})

        # バリデーション
        if not user_name:
            return create_response(400, {'error': 'userName is required'})

        if not exercise_id:
            return create_response(400, {'error': 'exerciseId is required'})

        valid_exercises = ['Memory', 'CPU', 'Tradeoff']
        if exercise_id not in valid_exercises:
            return create_response(400, {'error': f'exerciseId must be one of {valid_exercises}'})

        # タイムスタンプ
        timestamp = datetime.utcnow().isoformat() + 'Z'

        # DynamoDBアイテム
        item = {
            'pk': f'USER#{user_name}',
            'sk': f'EXERCISE#{exercise_id}',
            'userName': user_name,
            'exerciseId': exercise_id,
            'score': Decimal(str(score)),
            'details': json.loads(json.dumps(details), parse_float=Decimal),
            'updatedAt': timestamp,
            'createdAt': timestamp
        }

        # 既存レコードを確認
        response = table.get_item(
            Key={'pk': item['pk'], 'sk': item['sk']}
        )

        if 'Item' in response:
            item['createdAt'] = response['Item'].get('createdAt', timestamp)
            existing_score = float(response['Item'].get('score', 0))
            # スコアが低い場合は更新しない
            if score <= existing_score:
                return create_response(200, {
                    'message': 'Score not updated (existing score is higher or equal)',
                    'existingScore': existing_score,
                    'submittedScore': score
                })

        table.put_item(Item=item)

        return create_response(200, {
            'message': 'Score submitted successfully',
            'userName': user_name,
            'exerciseId': exercise_id,
            'score': score
        })

    except json.JSONDecodeError:
        return create_response(400, {'error': 'Invalid JSON'})


def handle_get_all_scores():
    """全ユーザーのスコアを取得"""
    response = table.scan()
    items = response.get('Items', [])

    # ユーザーごとにグループ化
    users = {}
    for item in items:
        user = item.get('userName')
        if user not in users:
            users[user] = {'userName': user, 'scores': []}
        users[user]['scores'].append({
            'exerciseId': item.get('exerciseId'),
            'score': item.get('score'),
            'details': item.get('details', {}),
            'updatedAt': item.get('updatedAt')
        })

    return create_response(200, {'users': list(users.values())})


def handle_get_user_scores(user_name):
    """特定ユーザーのスコアを取得"""
    from boto3.dynamodb.conditions import Key

    user_name = user_name.replace('%20', ' ')  # URLデコード

    response = table.query(
        KeyConditionExpression=Key('pk').eq(f'USER#{user_name}')
    )
    items = response.get('Items', [])

    scores = []
    for item in items:
        scores.append({
            'exerciseId': item.get('exerciseId'),
            'score': item.get('score'),
            'details': item.get('details', {}),
            'updatedAt': item.get('updatedAt')
        })

    return create_response(200, {
        'userName': user_name,
        'scores': scores
    })


def handle_get_ranking(exercise_id):
    """課題別ランキングを取得"""
    from boto3.dynamodb.conditions import Key

    # GSIを使用してクエリ
    try:
        response = table.query(
            IndexName='ExerciseIndex',
            KeyConditionExpression=Key('sk').eq(f'EXERCISE#{exercise_id}')
        )
    except Exception:
        # GSIがない場合はスキャンで代替
        response = table.scan(
            FilterExpression='exerciseId = :eid',
            ExpressionAttributeValues={':eid': exercise_id}
        )

    items = response.get('Items', [])

    # スコア降順でソート
    sorted_items = sorted(items, key=lambda x: float(x.get('score', 0)), reverse=True)

    ranking = []
    for i, item in enumerate(sorted_items, start=1):
        ranking.append({
            'rank': i,
            'userName': item.get('userName'),
            'score': item.get('score'),
            'details': item.get('details', {}),
            'updatedAt': item.get('updatedAt')
        })

    return create_response(200, {
        'exerciseId': exercise_id,
        'ranking': ranking
    })
